import sys
from ast import *
from ast_gen import *
from tacs import *
from tacs_gen import *
from basic_blocks import *
from asm import *
from asm_gen import *

def k_color(rig):
	coloring = {} # Maps nodes to colors

	# Get sorted list of nodes (fewest to greatest # edges)
	nodes = rig.keys()
	nodes.sort(key=lambda node : len(rig[node]))

	# Colors that can be used
	colors = [0]

	# Init first node, greatest # edges
	current_node = nodes.pop()
	coloring[current_node] = colors[0]

	# Color the nodes, ends when we've popped all the nodes
	while nodes:
		# Get a node
		current_node = nodes.pop()

		# Get the best color for this node
		best_color = -1
		for color in colors:
			is_valid_color = True
			adj_nodes = rig[current_node]

			# Does an adjacent node have this color?
			for adj in adj_nodes:
				if coloring.has_key(adj) and coloring[adj] == color:
					is_valid_color = False

			# No adjacent nodes have the color
			if is_valid_color:
				best_color = color
				break

		# No best color, add a new one to our list of possible colors
		if best_color == -1:
			colors.append(len(colors))
			best_color = colors[-1]

		print current_node
		# Set color of current node
		coloring[current_node] = best_color

	return (len(colors), coloring)

def is_assignee(inst, register):
	if hasattr(inst, 'assignee'):
		if inst.assignee == register:
			return True
	return False

def is_operand(inst, register):
	if hasattr(inst, 'op1'):
		if inst.op1 == register:
			return True
	if hasattr(inst, 'op2'):
		if inst.op2 == register:
			return True
	return False

def rig_delete(rig, register):
	for r in rig[register]:
		rig[r].discard(register)
	del rig[register]

def spill(blocks, register, num_spill):
	for block in blocks:
		new_insts = []
		for inst in block.insts:
			if is_operand(inst, register):
				new_insts += [TACLoad(register, num_spill)]
			new_insts += [inst]
			if is_assignee(inst, register):
				new_insts += [TACStore(register)] # Change this to offset at some point with a table

		block.insts = new_insts

def spill_and_fill(blocks, live_ranges, rig):
	colors = ['r8d', 'r9d', 'r10d', 'r11d', 'r12d', 'r13d', 'r14d', 'r15d', 'eax', 'ebx', 'ecx', 'edx', 'esi', 'edi']
	k = len(colors)

	num_spill = 0

	coloring = {}
	done = False
	while not done:
		# Refresh liveness information
		blocks = liveness(blocks)
		if rig:
			# Is it k-colorable?
			num_colors, coloring = k_color(rig)
			if k < num_colors:
				num_spill += 1
				# Spill register with greatest live range
				if live_ranges:
					spill_register = max(live_ranges, key=live_ranges.get)
					spill(blocks, spill_register, num_spill)
					# Remove spill register from rig and live_ranges
					if spill_register in rig:
						rig_delete(rig, spill_register)
					if spill_register in live_ranges:
						del live_ranges[spill_register]
			else:
				done = True

	blocks = liveness(blocks)

	return num_spill, coloring

def gen_rig(blocks):
	rig = {}
	# Construct register interference graph
	for block in blocks:
		# Iterate through live sets in each block
		for live_set in block.live_sets:
			# Add an edge between every two elements in the live sets in the graph (excluding self edges)
			for r1 in live_set:
				if r1 not in rig:
					rig[r1] = set()
				for r2 in live_set:
					if r1 != r2:
						if r2 not in rig:
							rig[r2] = set()
						rig[r1].add(r2)
						rig[r2].add(r1)
	return rig

def gen_live_ranges(blocks):
	live_ranges = {}
	for block in blocks:
		for live_set in block.live_sets:
		 	for register in live_set:
		 		if register in live_ranges:
		 			live_ranges[register] += 1
		 		else:
		 			live_ranges[register] = 1
	return live_ranges

# Reads in raw input (FOR AST DESERIALIZATION)
def read_input(filename):
    f = open(filename)
    lines = []
    for line in f:
        lines.append(line.rstrip('\n').rstrip('\r'))
    f.close()
    return lines

def write_output(filename, asm):
	f = open(filename[:-8] + ".s", 'w')
	s = ".section\t.rodata\n"
	s += ".int_fmt_string:\n"
	s += "\t.string \"%d\"\n"
	s += "\t.text\n"
	s += ".global\tmain\n"
	s += "\t.type\tmain, @function\n"
	s += "main:\n"
	f.write(s)
	for a in asm:
		f.write(str(a) + "\n")
	f.close()

def main():
	# AST DESERIALIZATION
	# .cl-type file
	filename = sys.argv[1]
	# Read AST from file
	raw_ast = read_input(filename)
	# Generate AST object
	ast = generate_ast(raw_ast)
	# Generate TAC instructions from AST object
	tacs = tac_ast(ast)
	# Generate basic blocks from TAC instructions
	blocks = make_bbs(tacs)

	# # Dead code elimination, computes liveness sets/ranges
	blocks = dead_code(blocks)

	# for block in blocks:
	# 	for ls in block.live_sets:
	# 		print ls

	# Register allocation

	# Generate live ranges for blocks
	live_ranges = gen_live_ranges(blocks)

	# Generate register interference graph
	rig = gen_rig(blocks)
	
	# for i in rig:
	# 	print i + ": " ,
	# 	for j in rig[i]:
	# 		print j + ", ",
	# 	print ""

	# Get coloring
	num_spill, coloring = spill_and_fill(blocks, live_ranges, rig)

	# for block in blocks:
	# 	for inst in block.insts:
	# 		print inst

	# Generate assembly
	asm = gen_asm(blocks, coloring, num_spill)

	write_output(filename, asm)

if __name__ == '__main__':
	main()
