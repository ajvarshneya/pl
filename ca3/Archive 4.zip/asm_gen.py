from tacs_gen import *
from asm import *

spill_stack_map = {}

def get_color(register, coloring):
	colors = ['r8d', 'r9d', 'r10d', 'r11d', 'r12d', 'r13d', 'r14d', 'r15d', 'eax', 'ebx', 'ecx', 'edx', 'esi', 'edi']
	return colors[int(coloring[register])]

def gen_asm(blocks, coloring, num_spill):
	global spill_stack_map

	asm = []

	# Base/stack pointer setup
	asm += [pushq('%rbp')]
	asm += [movq('%rsp', '%rbp')]

	# Allocate space for spilled registers on stack
	spill_space = 4 * num_spill
	if spill_space: asm += [subq('$' + str(spill_space), '%rsp')]

	spill_count = 0

	for block in blocks:
		for inst in block.insts:
			if isinstance(inst, TACAssign):		
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				asm += [movl(op1, assignee)]

			if isinstance(inst, TACPlus):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))

				asm += [comment('addition')] # debugging label
				if op2 == assignee:
					asm += [addl(op1, assignee)]
				else:
					asm += [movl(op1, assignee)]
					asm += [addl(op2, assignee)]

			if isinstance(inst, TACMinus):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))

				asm += [comment('subtraction')] # debugging label
				if op2 == assignee:
					asm += [subl(op1, assignee)]
					asm += [negl(assignee)]
				else:
					asm += [movl(op1, assignee)]
					asm += [subl(op2, assignee)]

			if isinstance(inst, TACMultiply):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))

				asm += [comment('multiplication')] # debugging label
				if op2 == assignee:
					asm += [imull(op1, assignee)]
				else:
					asm += [movl(op1, assignee)]
					asm += [imull(op2, assignee)]

			if isinstance(inst, TACDivide):
				assignee = '%' + str(get_color(inst.assignee, coloring)) # rX
				op1 = '%' + str(get_color(inst.op1, coloring)) # rY
				op2 = '%' + str(get_color(inst.op2, coloring)) # rZ

				asm += [comment('division')] # debugging label

				# Make room for temps on stack
				asm += [subq('$8', '%rsp')]

				# Save registers we will use
				asm += [pushq('%rdx')]
				asm += [pushq('%rax')]
				asm += [pushq('%rcx')]

				# Compute quotient rX = rY / rZ
				asm += [movl(op2, '24(%rsp)')] # rZ -> stack (in case its in eax)
				asm += [movl(op1, '%eax')] # rY -> eax
				asm += [cltd()] # zero extend eax into edx
				asm += [movl('24(%rsp)', '%ecx')] # rZ -> ecx
				asm += [idivl('%ecx')] # divide rY by rZ
				asm += [movl('%eax', '28(%rsp)')] # result -> stack

				# Restore registers
				asm += [popq('%rcx')]
				asm += [popq('%rax')]
				asm += [popq('%rdx')]

				# Save result, remove temp space
				asm += [movl('4(%rsp)', assignee)] # result -> rX
				asm += [addq('$8', '%rsp')]

			if isinstance(inst, TACLT):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))
				true_label = 'asm_label_' + nl()

				asm += [comment('less than')] # debugging label
				asm += [cmpl(op1, op2)]
				asm += [movl('$1', assignee)]
				asm += [jl(true_label)]
				asm += [movl('$0', assignee)]
				asm += [label(true_label)]

			if isinstance(inst, TACLEQ):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))
				true_label = 'asm_label_' + nl()

				asm += [comment('less than equals')] # debugging label
				asm += [cmpl(op1, op2)]
				asm += [movl('$1', assignee)]
				asm += [jle(true_label)]
				asm += [movl('$0', assignee)]
				asm += [label(true_label)]

			if isinstance(inst, TACEqual):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				op2 = '%' + str(get_color(inst.op2, coloring))
				true_label = 'asm_label_' + nl()
				
				asm += [comment('equals')] # debugging label
				asm += [cmpl(op1, op2)]
				asm += [movl('$1', assignee)]
				asm += [je(true_label)]
				asm += [movl('$0', assignee)]
				asm += [label(true_label)]

			if isinstance(inst, TACInt):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				value = '$' + str(inst.val)
				asm += [movl(value, assignee)]

			if isinstance(inst, TACBool):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				value = str(inst.val)
				if value == 'true':
					value = '$1'
				else:
					value = '$0'
				asm += [movl(value, assignee)]

			if isinstance(inst, TACNot):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				asm += [movl(op1, assignee)]
				asm += [xorl('$1', assignee)]

			if isinstance(inst, TACNeg):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				op1 = '%' + str(get_color(inst.op1, coloring))
				asm += [movl(op1, assignee)]
				asm += [negl(assignee)]			

			if isinstance(inst, TACDefault):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				asm += [movl('$0', assignee)]

			if isinstance(inst, TACOutInt):
				op1 = '%' + str(get_color(inst.op1, coloring))
				asm += [comment('out_int')] # debugging label

				asm += [pushq('%rax')] # save registers
				asm += [pushq('%rcx')]
				asm += [pushq('%rdx')]
				asm += [pushq('%rsi')]
				asm += [pushq('%rdi')]
				asm += [pushq('%r8')]
				asm += [pushq('%r9')]
				asm += [pushq('%r10')]
				asm += [pushq('%r11')]

				asm += [movl(op1, '%esi')] # put op1 in esi
				asm += [movl('$.int_fmt_string', '%edi')] # string format into edi
				asm += [movl('$0', '%eax')] # 0 into eax
				asm += [call('printf')] # print

				asm += [popq('%r11')] # restore registers
				asm += [popq('%r10')]
				asm += [popq('%r9')]
				asm += [popq('%r8')]
				asm += [popq('%rdi')]
				asm += [popq('%rsi')]
				asm += [popq('%rdx')]
				asm += [popq('%rcx')]
				asm += [popq('%rax')]

			if isinstance(inst, TACInInt):
				assignee = '%' + str(get_color(inst.assignee, coloring))
				
				asm += [comment('in_int')] # debugging label

				asm += [subq('$4', '%rsp')]

				asm += [pushq('%rax')] # save registers
				asm += [pushq('%rcx')]
				asm += [pushq('%rdx')]
				asm += [pushq('%rsi')]
				asm += [pushq('%rdi')]
				asm += [pushq('%r8')]
				asm += [pushq('%r9')]
				asm += [pushq('%r10')]
				asm += [pushq('%r11')]

				# 76 = 4 + 8*9
				asm += [leaq('72(%rsp)', '%rsi')]
				asm += [movl('$.int_fmt_string', '%edi')]
				asm += [movl('$0', '%eax')]

				asm += [call('__isoc99_scanf')]
				
				asm += [popq('%r11')] # restore registers
				asm += [popq('%r10')]
				asm += [popq('%r9')]
				asm += [popq('%r8')]
				asm += [popq('%rdi')]
				asm += [popq('%rsi')]
				asm += [popq('%rdx')]
				asm += [popq('%rcx')]
				asm += [popq('%rax')]

				asm += [movl('(%rsp)', assignee)]
				asm += [addq('$4', '%rsp')]

			if isinstance(inst, TACJmp):
				asm += [jmp(str(inst.label))]

			if isinstance(inst, TACLabel):
				asm += [label(str(inst.label))]

			if isinstance(inst, TACBt):
				value = '%' + str(get_color(inst.val, coloring))

				asm += [comment('branch')] # debugging label
				asm += [cmpl(value, '$1')]
				asm += [je(inst.label)]

			if isinstance(inst, TACStore):
				value = '%' + str(get_color(inst.val, coloring))
				if inst.val in spill_stack_map:
					offset = spill_stack_map[inst.val]
				else:
					spill_count += 1
					offset = str(-4 * spill_count)
					spill_stack_map[inst.val] = offset
				asm += [movl(value, offset + '(%rbp)')]

			if isinstance(inst, TACLoad):
				value = '%' + str(get_color(inst.val, coloring))
				offset = spill_stack_map[inst.val]
				asm += [movl(offset + '(%rbp)', value)]

			if isinstance(inst, TACReturn):
				value = '%' + str(get_color(inst.val, coloring))
				asm += [movl(value, '%eax')]
				asm += [leave()]
				asm += [ret()]

	return asm
